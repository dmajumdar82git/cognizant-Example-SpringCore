insert into Employee (id, name, age) values (1, 'Joe', 32);
insert into Employee (id, name, age) values (2, 'Sam', 28);
insert into Employee (id, name, age) values (3, 'John', 43);