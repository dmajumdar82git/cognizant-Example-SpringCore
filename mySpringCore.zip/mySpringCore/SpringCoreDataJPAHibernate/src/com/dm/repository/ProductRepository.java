package com.dm.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.dm.entities.Product;
@Component
public interface ProductRepository extends CrudRepository<Product,Integer>{

}
