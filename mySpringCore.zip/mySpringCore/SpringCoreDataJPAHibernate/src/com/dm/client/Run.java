package com.dm.client;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.dm.config.*;
import com.dm.entities.Product;
import com.dm.repository.ProductRepository;
@Configuration("mainBean")
@EnableJpaRepositories(basePackages = "com.dm.repository")
//@Import(SpringConfig.class)
@Transactional
public class Run {
	@Autowired
ProductRepository productRepository;
	
	void addProduct(int id,String name,String des,double price)
	{
		Product product=new Product();
		product.setId(id);
		product.setName(name);
		product.setDesc(des);
		product.setPrice(price);
		productRepository.save(product);
	}
	public void findAllEmployees() {
        productRepository.findAll().forEach(System.out::println);
    }
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
		System.out.println("java configeration loaded");
new Run().addProduct(1,"mobile","Samsung",12000);
		
	}

}
