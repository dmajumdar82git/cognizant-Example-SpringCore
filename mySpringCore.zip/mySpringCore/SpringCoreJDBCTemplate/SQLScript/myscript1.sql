use dmdb;
CREATE TABLE dmdb.MyTab (
        ID INTEGER NOT NULL,
        NAME VARCHAR(20) NOT NULL,
        PRIMARY KEY (ID)
    );