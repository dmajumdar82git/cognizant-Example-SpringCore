package com.dm.springCoreJdbcTemplate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("container.xml");
		
		EmployeeDao dao=(EmployeeDao)context.getBean("edao");
		int status=dao.insertEmployee(new Employee(100,"Debasri",85000));
		System.out.println(status);
		
		/*int status=dao.updateEmployee(new Employee(102,"Sonoo",15000));
		System.out.println(status);
		*/
		
		/*Employee e=new Employee();
		e.setId(102);
		int status=dao.deleteEmployee(e);
		System.out.println(status);*/
		
	}

}
