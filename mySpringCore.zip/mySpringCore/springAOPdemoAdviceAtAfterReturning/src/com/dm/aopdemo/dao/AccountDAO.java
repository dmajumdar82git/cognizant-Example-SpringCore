package com.dm.aopdemo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.dm.aopdemo.Account;

@Component
public class AccountDAO {

	public List findAccounts()
	{
		List<Account> acc=new ArrayList<>();
		Account acc1=new Account("Adrija");
		Account acc2=new Account("Swapna");
		Account acc3=new Account("Anannya");
		Account acc4=new Account("Soma");
		acc.add(acc1);acc.add(acc2);acc.add(acc3);acc.add(acc4);
		return acc;
	}
	
	public void addAccount()
	{
		System.out.println("Adding account: "+getClass());
	}
}
