package com.dm.aopdemo.dao;

import org.springframework.stereotype.Component;
import com.dm.aopdemo.Account;

@Component
public class AccountDAO {

	public double cal()
	{
		Account acc4=new Account("Soma",10);
		
		double n4=acc4.getNo()/0;
		return 10.0;
	}
	
	public void addAccount()
	{
		System.out.println("Adding account: "+getClass());
	}
}
