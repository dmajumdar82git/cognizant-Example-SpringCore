package com.dm.aopdemo;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dm.aopdemo.dao.AccountDAO;
import com.dm.aopdemo.dao.MembershipDAO;

public class Run {

	public static void main(String[] args) {
		// read spring config java class
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
//get the bean from spring container
AccountDAO accountDAO=context.getBean("accountDAO",AccountDAO.class);
System.out.println("printing from main app.......");
try{
	double p=accountDAO.cal();
}catch(Exception e)
{
	System.out.println("printing  from catch block of main app.......");
}
System.out.println("printing  from main app.......");
//close the context
context.close();
	}

}
