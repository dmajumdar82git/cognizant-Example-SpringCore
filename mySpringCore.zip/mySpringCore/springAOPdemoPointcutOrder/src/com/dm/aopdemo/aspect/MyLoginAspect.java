package com.dm.aopdemo.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(1)
public class MyLoginAspect {
	
	@Before("execution(* add*())")
		public void beforeAddAccount()
	{
		
		System.out.println("executing @Before advice on addAccount() ===> order 1");
		
	}
}
