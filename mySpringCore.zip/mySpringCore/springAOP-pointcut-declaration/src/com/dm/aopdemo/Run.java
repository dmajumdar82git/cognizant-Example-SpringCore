package com.dm.aopdemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dm.aopdemo.dao.AccountDAO;
import com.dm.aopdemo.dao.MembershipDAO;

public class Run {

	public static void main(String[] args) {
		// read spring config java class
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
//get the bean from spring container
AccountDAO accountDAO=context.getBean("accountDAO",AccountDAO.class);
MembershipDAO membershipDAO=context.getBean("membershipDAO",MembershipDAO.class);
//calling getter/setter
accountDAO.setName("dm");
accountDAO.getName();

//call the business method
accountDAO.addAccount();
membershipDAO.addAccount(new Account());
membershipDAO.addService();
//close the context
context.close();
	}

}
