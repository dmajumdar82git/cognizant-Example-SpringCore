package com.dm.aopdemo.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoginAspect {
//this is where we add all of our related advices for logging
	
	@Before("execution(* getService())")
	public void beforeGetService()
	{
		
		System.out.println("executing @before advice on getService()");
	
		
	}
	
	@After("execution(* getService())")
	public void afterGetService()
	{
		
		System.out.println("executing @after advice on getService()");
	
		
	}
	
	@AfterReturning(pointcut="execution(* getService())",
		            returning="result")
	public void afterGetServiceReturn()
	{
		
		System.out.println("executing @after return advice on getService()");
	
		
	}
	@Around("execution(* getService())")
	public Object aroundGetService(ProceedingJoinPoint pjp)throws Throwable
			{

	System.out.println("executing @around on getService()....=>"+pjp.getSignature().toShortString());
	long a=System.currentTimeMillis();
	Object res=pjp.proceed();
	long b=System.currentTimeMillis();
	long dur=b-a;
	System.out.println("delay.....");//+dur/1000.0);
	return null;

	}
	
}
