package com.dm.aopdemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dm.aopdemo.service.DemoService;

public class Run {

	public static void main(String[] args) {
		// read spring config java class
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
//get the bean from spring container

System.out.println("printing return value from main app.......");
DemoService demoService=(DemoService)context.getBean("demoService",DemoService.class);
String s=demoService.getService();
System.out.println(s);
//close the context
context.close();
	}

}
