package com.dm.annotation.springdi;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Run {

	public static void main(String[] args) {
	
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("containerAnnotation.xml");
		System.out.println("xml loaded");
		Student student=context.getBean("student",Student.class);
	student.display();
	//student.showResut();
	//student.showResut(new Exam());
	student.getService();
	context.close();
	}

}
