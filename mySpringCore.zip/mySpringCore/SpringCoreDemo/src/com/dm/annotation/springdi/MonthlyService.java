package com.dm.annotation.springdi;

import org.springframework.stereotype.Component;

@Component
public class MonthlyService implements StudentService
{

	@Override
	public void getTransport() {
		System.out.println("get Transport Service by Monthly Payment");
		
	}

	@Override
	public void getOnlineSudyMat() {
		System.out.println("get Online Study Materials Service by Monthly Payment");
	}

}
