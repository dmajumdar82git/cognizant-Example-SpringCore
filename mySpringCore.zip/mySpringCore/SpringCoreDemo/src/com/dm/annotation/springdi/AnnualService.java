package com.dm.annotation.springdi;

import org.springframework.stereotype.Component;

@Component
public class AnnualService implements StudentService
{

	@Override
	public void getTransport() {
		System.out.println("get Transport Service by Annual Payment");
		
	}

	@Override
	public void getOnlineSudyMat() {
		System.out.println("get Online Study Materials Service by Annual Payment");
	}

}
