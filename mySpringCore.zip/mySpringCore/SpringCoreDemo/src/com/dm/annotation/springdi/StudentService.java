package com.dm.annotation.springdi;

public interface StudentService {

	void getTransport();
	void getOnlineSudyMat();
}
