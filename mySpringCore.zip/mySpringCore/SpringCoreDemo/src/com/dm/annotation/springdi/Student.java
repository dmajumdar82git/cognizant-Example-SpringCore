package com.dm.annotation.springdi;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Student {

	private int id;
	private String name;
	//@Autowired
	//@Qualifier("monthlyService")//used for getting specific instance from multiple implementation of service
	private StudentService service;
	@Autowired//field injection
	private Exam exam;//dependency
//constructors	
 public Student() {	}
 @Autowired
public Student(@Qualifier("monthlyService")StudentService service) {
	super();
	this.service = service;
}

/// @Autowired////constructor injection
 /*public Student(Exam exam) {
	
		this.exam = exam;
	}
 public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Student(String name) {
		
		this.name = name;
	}

	public Student(int id) {

		this.id = id;
	
	}
	 public Student(int id, String name,Exam exam) {
			super();
			this.id = id;
			this.name = name;
			this.exam = exam;
		}*/
//setter & getter

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	//@Autowired//setter injection
	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public Exam getExam() {
		return this.exam;
	}

	//service methods
	
	public void display()
	{
		System.out.println("Student is: "+this.getName()+"\n Student id: "+this.getId());
	}
	//@Autowired//method injection
	void showResut(Exam exam)
	{
		//this.exam = exam;
		this.exam.getResult();
	}
	
	void getService()
	{
		this.service.getOnlineSudyMat();
		this.service.getTransport();
	}
	
	//custom method calling in bean lifecycle
	@PostConstruct
	void beforeInit()
	{
		System.out.println("custom method calling before: ");
	}
	@PreDestroy
	void afterDestroy()
	{
		System.out.println("custom method calling after: ");
	}
}
