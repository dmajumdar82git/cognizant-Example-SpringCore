package com.dm.annotation.javaconfig_noxml;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.dm.annotation.javaconfig_noxml")
public class SpringConfig {

}
