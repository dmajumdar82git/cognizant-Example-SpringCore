package com.dm.annotation.javaconfig_noxml;

public interface SIM {
	void calling();
	void data();
	void sms();
	
}
