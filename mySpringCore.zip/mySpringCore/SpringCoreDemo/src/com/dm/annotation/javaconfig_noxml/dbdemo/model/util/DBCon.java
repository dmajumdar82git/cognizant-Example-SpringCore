package com.dm.annotation.javaconfig_noxml.dbdemo.model.util;
import java.sql.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class DBCon {
Connection con=null;
//String driver="com.mysql.jdbc.Driver";
//String URL="jdbc:mysql://localhost:3306/mydb";
@Value("${db.driver}")
private String driver;
@Value("${db.URL}")
private String URL;
public Connection getCon()throws SQLException,ClassNotFoundException
{
Class.forName(driver);	
	con=DriverManager.getConnection(URL, "root","root");
	
	
return con;	
}
	
}
