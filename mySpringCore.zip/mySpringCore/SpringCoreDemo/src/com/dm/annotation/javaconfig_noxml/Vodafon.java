package com.dm.annotation.javaconfig_noxml;

import org.springframework.stereotype.Component;
//using default component name
@Component
public class Vodafon implements SIM{

	@Override
	public void calling() {
		System.out.println("calling using Vodafon sim");
		
	}
	@Override
	public void data() {
		System.out.println("using Vodafon internet");
		
	}
	@Override
	public void sms() {
		System.out.println("using Vodafon messaging");
		
	}


}
