package com.dm.annotation.javaconfig_noxml.dbdemo.model;
import java.util.List;

import com.dm.annotation.javaconfig_noxml.dbdemo.beans.UserDetails;


public interface UserDao {

	public List<UserDetails> show()throws Exception;
	public void take(UserDetails usr)throws Exception;
}
