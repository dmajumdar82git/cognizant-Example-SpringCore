package com.dm.annotation.javaconfig_noxml.dbdemo.service;
import com.dm.annotation.javaconfig_noxml.dbdemo.beans.UserDetails;
import com.dm.annotation.javaconfig_noxml.dbdemo.model.UserDao;
import com.dm.annotation.javaconfig_noxml.dbdemo.model.UserDaoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDao userDao;
	List<UserDetails> usr=null;
	@Override
	public List<UserDetails> display() {
		try {
			usr=userDao.show();
		return usr;
	}catch(Exception e)
		{System.out.println(e.getMessage());}
		return usr;
}
	@Override
	public void insert(UserDetails usr) {
		// TODO Auto-generated method stub
		
	}
}