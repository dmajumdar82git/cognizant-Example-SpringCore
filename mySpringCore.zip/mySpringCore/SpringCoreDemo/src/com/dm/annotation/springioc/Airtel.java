package com.dm.annotation.springioc;

import org.springframework.stereotype.Component;

@Component("simA")
public class Airtel implements SIM {

	
	@Override
	public void calling() {
		System.out.println("calling using airtel sim");
		
	}

	@Override
	public void data() {
		System.out.println("using airtel internet");
		
	}

	@Override
	public void sms() {
		System.out.println("using airtel messaging");
		
	}

}
