package com.dm.annotation.springioc;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Mobile {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("containerAnnotation.xml");
		System.out.println("xml loaded");
		SIM sim=context.getBean("simA",SIM.class);
		sim.calling();
		sim.data();
		sim.sms();
		SIM sim2=context.getBean("vodafon",SIM.class);//id is given automatically
		sim2.calling();
		sim2.data();
		sim2.sms();
		context.close();
	}

}
