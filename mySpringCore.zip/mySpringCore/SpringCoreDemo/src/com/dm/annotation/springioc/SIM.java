package com.dm.annotation.springioc;

public interface SIM {
	void calling();
	void data();
	void sms();
	
}
