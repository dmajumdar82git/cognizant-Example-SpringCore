package com.dm.xml.springdi;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Run {

	public static void main(String[] args) {
	/*Student stud=new Student();
	stud.setName("debasri");
	*/
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("container.xml");
		System.out.println("xml loaded");
		/*Student stud1=context.getBean("stud",Student.class);
		
		stud1.display();
		
Student stud2=context.getBean("stud1",Student.class);
		
		stud2.display();
Student stud3=context.getBean("stud2",Student.class);
		
		stud3.display();
*/
	Student student=context.getBean("sd",Student.class);
	student.display();
	context.close();
	}

}
