package com.dm.xml.springdi;

public class Exam {

	private String result;

	public Exam() {	}

	public Exam(String result) {
		super();
		this.result = result;
	}
	
	public void setResult(String result) {
		this.result = result;
	}

	void getResult()
	{
		System.out.println("Result has got published...  "+result);
	}
	//custom init method
void myCustomInit()
{
	System.out.println("Caslling my custom init method");
	}
//custom destroy method
void myCustomDestroy()
{
	System.out.println("Caslling my custom destroy method");
	}
}
