package com.dm.stereotype;

public class Vodafon implements SIM{

	@Override
	public void calling() {
		System.out.println("calling using Vodafon sim");
		
	}
	@Override
	public void data() {
		System.out.println("using Vodafon internet");
		
	}


}
