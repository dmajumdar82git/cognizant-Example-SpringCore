package com.dm.stereotype;

public class Mobile {

	public static void main(String[] args) {
		//to use airtel
		Airtel airtel=new Airtel();
		airtel.calling();
		airtel.data();
		//to use vodafon
		Vodafon vodafon =new Vodafon();
		vodafon.calling();
		vodafon.data();
				
		//best approach
		
		
		SIM sim=new Airtel();//new Vodafon();
		sim.calling();
		sim.data();
		//this is dependency and hard coupled
		// in order to make it a loose couple code that will be flexible and configerable
		//use spring Ioc container
		//what we need it register our required onjects in spring configuration file
		//and Spring Container=>Ioc container is going to create and hold all object that we are going to use
		//for doing so spring needs container either by BeanFactory(interface...a legacy type of thing) or ApplicationContext
		//a sperset of BF
		//we need to use ClassPathXMLApplicationContext implementor class for that a  need to use getBean("resource name")
	//1st we need to add spring library to java build path	
	}

}
