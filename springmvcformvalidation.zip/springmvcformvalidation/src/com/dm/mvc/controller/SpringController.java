package com.dm.mvc.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.mvc.model.Student;


@Controller
public class SpringController {
	@RequestMapping("/")
	public String showHome()
	{
		return "myHome";
	}
		@RequestMapping("/showForm")
	public String showPage(Model model)
	{
		Student student = new Student();
		model.addAttribute("student", student);
		return "springForm";
	}
	@RequestMapping("/processForm")
	public String showResult(@Valid @ModelAttribute("student") Student stud,BindingResult res)
	{
		if(res.hasErrors())
				return "springForm";
		else
			return "display";
	}
}
