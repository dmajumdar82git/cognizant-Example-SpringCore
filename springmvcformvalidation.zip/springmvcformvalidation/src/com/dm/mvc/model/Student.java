package com.dm.mvc.model;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Student {
//@NotNull(message="is required")
@Size(min=1,message="name is required")
private String name;




public Student() {
	
//9674939609
    
}


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

	
}
