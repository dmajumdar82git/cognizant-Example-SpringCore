package com.dm.mvc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String showPage()
	{
		return "myHome";
	}
	@RequestMapping("/showForm")
	public String showForm()
	{
		return "form1";
	}
	@RequestMapping("/processForm")
	public String showResult(HttpServletRequest req,Model model)
	{
		String myName=req.getParameter("name");
		myName="hello! "+myName;
		model.addAttribute("mseg", myName);
		return "display1";
	}
}
