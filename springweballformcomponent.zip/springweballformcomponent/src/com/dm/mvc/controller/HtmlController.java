package com.dm.mvc.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.mvc.model.Student;

@Controller
@RequestMapping("/html")
public class HtmlController {
	@RequestMapping("/showForm")
	public String showPage()
	{
		return "myForm";
	}
	@RequestMapping("/processForm")
	public String showResult(@RequestParam("name")String name,@RequestParam("add")String add,@RequestParam("city")String city,
			@RequestParam("topic")List<String> topic,@RequestParam("session")String session,Model model)
	{
		Student s=new Student();
		s.setAddress(add);
		s.setCity(city);
		s.setName(name);
		s.setSession(session);
		s.setTopics(topic);
		model.addAttribute("student",s);
		return "display";
	}
}
