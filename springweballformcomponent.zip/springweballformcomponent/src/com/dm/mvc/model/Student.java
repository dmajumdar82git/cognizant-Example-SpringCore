package com.dm.mvc.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

public class Student {
private String name;
private String address;
private String city;
private String country;
private List<String> topics;
private String session;
private HashMap<String, String> languageOptions;


public Student() {
	this.languageOptions = new HashMap<>();

    // parameter order: value, display label
    this.languageOptions.put("Java", "Java");
    this.languageOptions.put("C#", "C#");
    this.languageOptions.put("Pythone", "Pythone");
    this.languageOptions.put("Ruby", "Ruby");       
	
}

public HashMap<String, String> getLanguageOptions() {
	return languageOptions;
}

public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

public List<String> getTopics() {
	return topics;
}
public void setTopics(List<String> topics) {
	this.topics = topics;
}
public String getSession() {
	return session;
}
public void setSession(String session) {
	this.session = session;
}

	
}
